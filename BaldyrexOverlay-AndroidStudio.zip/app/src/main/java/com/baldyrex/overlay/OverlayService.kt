package com.baldyrex.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.SeekBar
import android.view.MotionEvent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var drawing: AimView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) createOverlay()
        return START_STICKY
    }

    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 100 }
        params = p

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.argb(235, 13, 19, 29))
        }
        val header = TextView(this).apply {
            text = "≡  BALDYREX CONTROL  •  drag"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(0, 235, 170))
            setPadding(4, 4, 4, 12)
        }
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> { p.x=ox+(e.rawX-sx).toInt(); p.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(root,p); return true }
                }
                return true
            }
        })
        root.addView(header)
        val close = TextView(this).apply {
            text = "✕  ЗАКРЫТЬ ПАНЕЛЬ"
            setTextColor(Color.WHITE); setPadding(4, 8, 4, 8)
            setOnClickListener { stopSelf() }
        }
        root.addView(close)
        addToggle(root, "Прицел", true) { drawing?.crosshair = it; drawing?.invalidate() }
        addToggle(root, "Круг FOV", true) { drawing?.fov = it; drawing?.invalidate() }
        addToggle(root, "Индикатор направления", false) { drawing?.direction = it; drawing?.invalidate() }
        addToggle(root, "Тренировочный таймер", true) { drawing?.timer = it; drawing?.invalidate() }

        addLabel(root, "Размер прицела")
        addSlider(root, 5, 60, 24) { drawing?.size = it.toFloat(); drawing?.invalidate() }
        addLabel(root, "Радиус FOV")
        addSlider(root, 20, 240, 100) { drawing?.radius = it.toFloat(); drawing?.invalidate() }

        panel = root
        wm.addView(root, p)

        val d = AimView(this)
        val dp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        drawing = d
        wm.addView(d, dp)
    }

    private fun addLabel(root: LinearLayout, text: String) {
        root.addView(TextView(this).apply { this.text=text; textSize=13f; setTextColor(Color.LTGRAY); setPadding(2,8,2,0) })
    }

    private fun addToggle(root: LinearLayout, label: String, initial: Boolean, change: (Boolean)->Unit) {
        var state = initial
        root.addView(TextView(this).apply {
            text = (if (state) "☑  " else "□  ") + label
            textSize=14f; setTextColor(Color.WHITE); setPadding(4,9,4,9)
            setOnClickListener { state=!state; text=(if(state) "☑  " else "□  ")+label; change(state) }
        })
    }

    private fun addSlider(root: LinearLayout, min: Int, max: Int, initial: Int, change: (Int)->Unit) {
        root.addView(SeekBar(this).apply {
            this.max=max-min; progress=initial-min
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) { if(fromUser) change(value+min) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        drawing?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel=null; drawing=null
        super.onDestroy()
    }
}

class AimView(context: android.content.Context) : View(context) {
    var crosshair = true
    var fov = true
    var direction = false
    var timer = true
    var size = 24f
    var radius = 100f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 235, 170); strokeWidth = 2.5f; style = Paint.Style.STROKE
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val x=width/2f; val y=height/2f
        if (fov) canvas.drawCircle(x,y,radius,paint)
        if (crosshair) {
            canvas.drawLine(x-size,y,x+size,y,paint)
            canvas.drawLine(x,y-size,x,y+size,paint)
            canvas.drawCircle(x,y,3f,paint)
        }
        if (direction) {
            paint.style=Paint.Style.FILL
            canvas.drawText("CENTER", x+18, y-18, paint)
            paint.style=Paint.Style.STROKE
        }
        if (timer) {
            paint.style=Paint.Style.FILL
            paint.textSize=14f
            canvas.drawText("TRAINING HUD", 24f, height-32f, paint)
            paint.style=Paint.Style.STROKE
        }
    }
}
