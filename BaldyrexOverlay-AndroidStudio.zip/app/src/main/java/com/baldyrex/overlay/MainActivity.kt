package com.baldyrex.overlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 40)
            setBackgroundColor(Color.rgb(12, 16, 24))
        }
        val title = TextView(this).apply {
            text = "BALDYREX  /  MOBILE OVERLAY"
            textSize = 22f
            setTextColor(Color.rgb(0, 235, 170))
        }
        val info = TextView(this).apply {
            text = "\nПлавающая панель с прицелом, FOV и тренировочными индикаторами.\n\nOverlay не читает память игры, не определяет игроков и не управляет стрельбой."
            textSize = 15f
            setTextColor(Color.WHITE)
        }
        val start = Button(this).apply {
            text = "ВКЛЮЧИТЬ OVERLAY"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                }
            }
        }
        val stop = Button(this).apply {
            text = "ОСТАНОВИТЬ OVERLAY"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        box.addView(title); box.addView(info); box.addView(start); box.addView(stop)
        setContentView(box)
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && intent.getBooleanExtra("start", false)) {
            startService(Intent(this, OverlayService::class.java))
        }
    }
}
